// **************************************************************************************
// * Web Server (web_server_s.cc)
// * 
// **************************************************************************************
#include "echo_s.h"
using namespace std;

// function to check to ensure that the request is valid
  // (it should be a GET request for a filename of the correct format)

// **************************************************************************
// * Read the header. Return the appropriate status code and filename 
// **************************************************************************
int readRequest(int sockFd, string &filename) {
  // set default return code to 400
  int returnCode = 400;

  // read everything up to and including the end of the header
  char *buffer = new char[11];
  bzero(buffer, 11);
  string header = "";

    // loop throught and read input
  DEBUG << "Calling read function." << ENDL;
  bool done = false;
  while(!done) {
    // zero out the buffer
    bzero(buffer, 11);

    // read a small amount of input
    int inputSize = read(sockFd, buffer, 10);
    header += buffer;

    // check if we have reached the end of input
    if ((header.length() >= 4) && (header.substr(header.length() - 4) == "\r\n\r\n")) {
      done = true;
    }
  }
  DEBUG << "Finished reading in header." << ENDL;
  DEBUG << "INPUT: " << header << ENDL;

  // check if there is a valid GET request
  if (header[0] == 'G' && header[1] == 'E' && header[2] == 'T') {
    done = false;
    DEBUG << "There is a valid GET request. Finding filename in header." << ENDL;
    filename = "";
  } else {
    done = true;
  }

  // if so, find the file name
  int slashIndex = 0;
  int counter = 4;
  while(!done) {
    if (header[counter] == '/') {
      slashIndex = counter;
    } else if (header[counter - 3] == 'j' && header[counter - 2] == 'p' && header[counter - 1] == 'g') {
        if (header[counter] != '\n') {
          for (int i = slashIndex + 1; i < counter; i++) {
            filename += header[i];
          }
        }
        done = true;
    } else if (header[counter] == ' ' && header[counter - 2] == 'm' && header[counter - 1] == 'l') {
        if (header[counter] != '\n') {
          for (int i = slashIndex + 1; i < counter; i++) {
            filename += header[i];
          }
        }
        done = true;
    }
    counter++;
  }
  DEBUG << "The filename is \"" << filename << "\"" << ENDL;


  // check to see if the filename is valid
  if (filename[0] == 'f' && filename[1] == 'i' && filename[2] == 'l' && filename[3] == 'e') {
    if (filename[4] == '0' || filename[4] == '1' || filename[4] == '2' || filename[4] == '3' ||
    filename[4] == '4' || filename[4] == '5' || filename[4] == '6' || filename[4] == '7' ||
    filename[4] == '8' || filename[4] == '9') {
      // if the filename is valid, set return code to 200
      DEBUG << "Filename is valid. Return code is 200." << ENDL;
      returnCode = 200;
    }
  } else if (filename[0] == 'i' && filename[1] == 'm' && filename[2] == 'a' && filename[3] == 'g' &&
    filename[4] == 'e') {
      if (filename[5] == '0' || filename[5] == '1' || filename[5] == '2' || filename[5] == '3' ||
      filename[5] == '4' || filename[5] == '5' || filename[5] == '6' || filename[5] == '7' ||
      filename[5] == '8' || filename[5] == '9') {
        // if the filename is valid, set return code to 200
        DEBUG << "Filename is valid. Return code is 200." << ENDL;
        returnCode = 200;
      }
  } else {
    // if the filename is invalid set the return code to 404
    returnCode = 404;
  }

  // return the previously determined return code
  return returnCode;
}

// ****************************************************************************
// * Send one line (including the line terminator <LF><CR>)
// ****************************************************************************
void sendLine(int sockFd, string stringToSend) {
  // DEBUG << stringToSend << ENDL;
  // convert the string to an array + 2 bytes
  int arraySize = stringToSend.length() + 2;
  char arrayToSend[arraySize];
  for (int i = 0; i < arraySize; i++) {
    arrayToSend[i] = stringToSend[i];
  }

  // replace last two bytes with <CR> and <LF>
  arrayToSend[arraySize - 1] = '\r';
  arrayToSend[arraySize - 2] = '\n';

  // use write to send the array
  // DEBUG << "Calling write(" << sockFd << ", " << &arrayToSend << ", " << arraySize << ")" << ENDL;
  write(sockFd, arrayToSend, arraySize);
  // DEBUG << "Wrote " << arraySize << " back to client." << ENDL;

  // return
  return;
}


// ****************************************************************************
// * Send a 404
// ****************************************************************************
void send404(int sockFd) {
  // use sendLine() to send a correctly formatted 404 message
  
    // send an HTTP response with the error code 404
  sendLine(sockFd, "HTTP/1.1 404 Not Found");
    // send the string: "content-type: text/html" to indicate we are sending a message
  sendLine(sockFd, "content-type: text/html");
    // send a blank line to terminate the header
  sendLine(sockFd, "");
  sendLine(sockFd, "");


    // send a friendly message that indicates what the problem is
  sendLine(sockFd, "The file you are looking for is invalid or was not found.");
    // send a blank line to indicate the end of the message body
  sendLine(sockFd, "");

  //return
  return;
}

// ****************************************************************************
// * Send a 400
// ****************************************************************************
void send400(int sockFd) {
    // use sendLine() to send a correctly formatted 400 message
  
    // send an HTTP response with the error code 400
  sendLine(sockFd, "HTTP/1.1 400 Bad Request");
    // send a blank line to terminate
  sendLine(sockFd, "");

  //return
  return;
}

// ****************************************************************************
// * Send a file
// ****************************************************************************
void sendFile(int sockFd, string &filename) {
  // change file name from string to const char *
  const char *filename_pointer = filename.c_str();
  struct stat buffer;

  // use the stat() function to find the size of the file
  DEBUG << "Calling stat() to find size of file." << ENDL;
  int check_error = stat(filename_pointer, &buffer);

  // check to see if the stat() function failed
  if (check_error < 0) {
    // no read permission or the file does not exist
    // send 404 error
    DEBUG << "The stat() function failed, sending 404 error message." << ENDL;
    send404(sockFd);
  }

  /*
  *  send the header
  */
 DEBUG << "Sending the file header." << ENDL;

  // send a properly formatted HTTP response with error code 200
  string line_to_send = "HTTP/1.1 200 OK";
  sendLine(sockFd, line_to_send);
    // send the content-length
  size_t file_size = buffer.st_size;
  line_to_send = "Content-Length: " + std::to_string(file_size);
  sendLine(sockFd, line_to_send);
  DEBUG << "The size of the file is: " << file_size << ENDL;
  // send the content type
  if (strncmp(filename_pointer, "file", 4) == 0) {
    DEBUG << "Content type: text file." << ENDL;
    line_to_send = "Content-Type: text/html";
    sendLine(sockFd, line_to_send);
  } else {
    DEBUG << "Content type: image." << ENDL;
    line_to_send = "Content-Type: image/jpeg";
    sendLine(sockFd, line_to_send);
  }
  // send a blank line to terminate the header
  sendLine(sockFd, "");
  sendLine(sockFd, "");


  /*
  *  send the file itself
  */
  DEBUG << "Sending the file." << ENDL;

  // open the file
  DEBUG << "Opening file." << ENDL;
  int file_input = open(filename_pointer, O_RDONLY);
  // allocate 10 bytes of memory
   char *input = new char[10];
  
  int bytesLeft = file_size;
  int counter = 0;
  while (bytesLeft != 0) {
    // clear out memory and keep track of the bytes read
    bzero(input, 10);

    // read from file into memory buffer
    ssize_t nRead = read(file_input, input, 10);
    // DEBUG << "2.5..." << input << "...nRead: " << nRead << "...bytesLeft: " << bytesLeft << ENDL;

    // write the number of bytes that was read
    write(sockFd, input, nRead);
    bytesLeft -= nRead;
  }


  // close the file
  DEBUG << "Closing file." << ENDL;
  close(file_input);
  filename = "";

  DEBUG << "File sent. Returning." << ENDL;
  // return - no need for line terminator since content-length was set
  return;
  
}



// **************************************************************************************
// * processConnection()
// * - same processConnection function from proj 1
// * - with different data manipulation inside
// **************************************************************************************
int processConnection(int sockFd) {
  string filename = "";

  // get the return code
  DEBUG << "Calling readRequest()" << ENDL;
  int returnCode = readRequest(sockFd, filename);

  if (returnCode == 400) {  // if returnCode is 400 then send the 400 message
    DEBUG << "Sending 400 message." << ENDL;
    send400(sockFd);
    DEBUG << "400 message sent." << ENDL;
  } else if (returnCode == 404) {   // if returnCode is 404 then send the 404 message
    DEBUG << "Sending 404 message." << ENDL;
    send404(sockFd);
    DEBUG << "404 message sent." << ENDL;
  } else if (returnCode == 200) {   // if the returnCode is 200 then send the file
    DEBUG << "Sending file." << ENDL;
    sendFile(sockFd, filename);
    DEBUG << "File sent." << ENDL;
  }

  // exit the function and return 0, so the main loop will close the connection and wait for the next request
  return 0;
}
    


// **************************************************************************************
// * main()
// * - Sets up the sockets and accepts new connection until processConnection() returns 1
// **************************************************************************************

int main (int argc, char *argv[]) {

  // ********************************************************************
  // * Process the command line arguments
  // ********************************************************************
  boost::log::add_console_log(std::cout, boost::log::keywords::format = "%Message%");
  boost::log::core::get()->set_filter(boost::log::trivial::severity >= boost::log::trivial::info);

  // ********************************************************************
  // * Process the command line arguments
  // ********************************************************************
  int opt = 0;
  while ((opt = getopt(argc,argv,"v")) != -1) {
    
    switch (opt) {
    case 'v':
      boost::log::core::get()->set_filter(boost::log::trivial::severity >= boost::log::trivial::debug);
      break;
    case ':':
    case '?':
    default:
      std::cout << "useage: " << argv[0] << " -v" << std::endl;
      exit(-1);
    }
  }

  // *******************************************************************
  // * Creating the inital socket is the same as in a client.
  // ********************************************************************
  int listenfd = -1;
  DEBUG << "Calling Socket() assigned file descriptor " << listenfd << ENDL;

  // Call socket() to create the socket you will use for listening.
  listenfd = socket(PF_INET, SOCK_STREAM, 0);

  // check for error
  if ((listenfd = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
      cout << "Failed to create listening socket " << strerror(errno) <<  endl;
      exit(-1);
  }

  
  // ********************************************************************
  // * The bind() and calls take a structure that specifies the
  // * address to be used for the connection. On the cient it contains
  // * the address of the server to connect to. On the server it specifies
  // * which IP address and port to lisen for connections.
  // ********************************************************************
  struct sockaddr_in servaddr;
  srand(time(NULL));
  int port = (rand() % 5000) + 5000;
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = PF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = htons(port);


  // ********************************************************************
  // * Binding configures the socket with the parameters we have
  // * specified in the servaddr structure.  This step is implicit in
  // * the connect() call, but must be explicitly listed for servers.
  // ********************************************************************
  DEBUG << "Calling bind(" << listenfd << "," << &servaddr << "," << sizeof(servaddr) << ")" << ENDL;
  int bindSuccessful = 0;
    while (!bindSuccessful) {
            // You may have to call bind multiple times if another process is already using the port
            // your program selects.
            bindSuccessful = bind(listenfd, (sockaddr *) &servaddr, sizeof(servaddr));

            if (!bindSuccessful) {
                port = port++;
                servaddr.sin_port = htons(port);
            }
    }
    cout << "Using port " << port << endl;


  // ********************************************************************
  // * Setting the socket to the listening state is the second step
  // * needed to being accepting connections.  This creates a queue for
  // * connections and starts the kernel listening for connections.
  // ********************************************************************
  int listenQueueLength = 1;
  DEBUG << "Calling listen(" << listenfd << "," << listenQueueLength << ")" << ENDL;

  listen(listenfd, listenQueueLength);

  // check for error
  int listenq = 1;
  if (listen(listenfd, listenq) < 0) {
      cout << "listen() failed: " << strerror(errno) <<  endl;
      exit(-1);
  }
 

  // ********************************************************************
  // * The accept call will sleep, waiting for a connection.  When 
  // * a connection request comes in the accept() call creates a NEW
  // * socket with a new fd that will be used for the communication.
  // ********************************************************************
  int quitProgram = 0;
  while (!quitProgram) {
    int connFd = 0;

    DEBUG << "Calling accept(" << listenfd << ",NULL,NULL)." << ENDL;
    connFd = accept(listenfd, NULL, NULL);

    // The accept() call checks the listening queue for connection requests.
    // If a client has already tried to connect accept() will complete the
    // connection and return a file descriptor that you can read from and
    // write to. If there is no connection waiting accept() will block and
    // not return until there is a connection.
    
    DEBUG << "We have recieved a connection on " << connFd << ENDL;

    
    quitProgram = processConnection(connFd);
   
    close(connFd);
  }

  close(listenfd);

}

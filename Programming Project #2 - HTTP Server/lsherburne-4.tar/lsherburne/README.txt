# Name: Lauren Sherburne
# To run: untar the files, navigate into the directory, type make, type ./echo_s with or without -v as necessary
